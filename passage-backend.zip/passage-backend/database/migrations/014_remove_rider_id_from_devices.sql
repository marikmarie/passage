ALTER TABLE devices
  DROP COLUMN IF EXISTS rider_id;
